package ij3d;

public interface TimelapseListener {

	public void timepointChanged(int timepoint);
}
