/* -*- mode: java; c-basic-offset: 8; indent-tabs-mode: t; tab-width: 8 -*- */

/**
 * Example plugin on how to add spheres and tubes to the 3D Viewer.
 * Albert Cardona 2008-12-09
 * Released under the General Public License, latest version.
 */

package ij3d;

/**
 * @Deprecated Use customnode.Mesh_Maker instead.
 */
public class Mesh_Maker extends customnode.Mesh_Maker {
}

