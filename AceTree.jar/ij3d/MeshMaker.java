package ij3d;

/**
 * @Deprecated use customnode.MeshMaker instead.
 */
public class MeshMaker extends customnode.MeshMaker {
}
